// You can add custom JavaScript here if needed
// JavaScript to highlight items when mouse hovers over them
document.addEventListener('DOMContentLoaded', function () {
    // Select all elements with the class 'card'
    const cards = document.querySelectorAll('.card');

    // Add event listeners for mouseenter and mouseleave events
    cards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            card.style.backgroundColor = '#f0f8ff'; // Light blue highlight
            card.style.transition = 'background-color 0.3s'; // Smooth transition
        });

        card.addEventListener('mouseleave', () => {
            card.style.backgroundColor = ''; // Revert to original background color
        });
    });
});
