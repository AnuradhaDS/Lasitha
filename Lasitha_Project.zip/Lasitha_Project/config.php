<?php
// config.php

// Define the absolute server path of the project
define('BASE_PATH', __DIR__ . '/');

// Function to get the base URL of the project
function base_url($path = '') {
    return 'localhost/Lasitha_Project/' . $path;
}
?>

