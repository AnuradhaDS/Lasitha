
<!-- admin/dashboard.php -->
<?php
include 'includes/header.php';
?>

<div class="container mt-4">
    <h2>Admin Dashboard</h2>
    <div class="row">
        <div class="col-md-3">
            <a href="manage_users.php" class="btn btn-primary btn-block">Manage Users</a>
        </div>
        <div class="col-md-3">
            <a href="manage_staff.php" class="btn btn-primary btn-block">Manage Staff</a>
        </div>
        <div class="col-md-3">
            <a href="manage_menu.php" class="btn btn-primary btn-block">Manage Menu</a>
        </div>
        <div class="col-md-3">
            <a href="manage_reservations.php" class="btn btn-primary btn-block">Manage Reservations</a>
        </div>
    </div>
</div>

<?php
include 'includes/footer.php';


session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    // Redirect to login if not logged in or not an admin
    header("Location: ../login.php");
    exit();
}

include 'includes/header.php';
?>

<div class="container mt-4">
    <h2>Welcome to the Admin Dashboard, <?php echo $_SESSION['username']; ?></h2>
    <!-- Admin dashboard content -->
</div>

<?php
include 'includes/footer.php';
?>
