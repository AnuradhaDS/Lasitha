<!-- admin/manage_reservations.php -->
<?php
include 'includes/header.php';
include 'includes/db.php';

$sql = "SELECT * FROM reservations";
$result = $conn->query($sql);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reservation_id = $_POST['reservation_id'];
    $status = $_POST['status'];

    $update_sql = "UPDATE reservations SET status = '$status' WHERE id = $reservation_id";
    $conn->query($update_sql);
    header('Location: manage_reservations.php');
}
?>

<div class="container mt-4">
    <h2>Manage Reservations</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Customer Name</th>
                <th>Date</th>
                <th>Time</th>
                <th>Table Size</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['customer_name']; ?></td>
                <td><?php echo $row['date']; ?></td>
                <td><?php echo $row['time']; ?></td>
                <td><?php echo $row['table_size']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <form action="" method="post">
                        <input type="hidden" name="reservation_id" value="<?php echo $row['id']; ?>">
                        <select name="status">
                            <option value="accepted">Accept</option>
                            <option value="rejected">Reject</option>
                        </select>
                        <button type="submit" class="btn btn-sm btn-primary">Update</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php
include 'includes/footer.php';
$conn->close();
?>
