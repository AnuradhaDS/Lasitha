
<footer class="bg-light text-center text-lg-start">
    <div class="text-center p-3">
        © 2024 The Gallery Café
    </div>
</footer>
