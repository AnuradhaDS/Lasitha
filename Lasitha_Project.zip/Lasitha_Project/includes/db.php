<?php
$servername = "localhost";
$username = "lasitha"; // Your XAMPP MySQL username
$password = "lasitha-pass"; // Your XAMPP MySQL password
$dbname = "gallery_cafe"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
