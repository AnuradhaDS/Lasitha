<?php
include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_name = $_POST['customer_name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $table_size = $_POST['table_size'];

    $stmt = $conn->prepare("INSERT INTO reservations (customer_name, date, time, table_size) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $customer_name, $date, $time, $table_size);
    if ($stmt->execute()) {
        echo "Reservation successfully made!";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$conn->close();
?>
<a href="index.php">Go Back</a>
