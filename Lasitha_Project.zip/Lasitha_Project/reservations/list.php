<?php
include 'includes/db.php';
include 'includes/header.php';

$sql = "SELECT * FROM reservations ORDER BY date, time";
$result = $conn->query($sql);
?>

<div class="container">
    <h2 class="mt-4">Upcoming Reservations</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Customer Name</th>
                <th>Date</th>
                <th>Time</th>
                <th>Table Size</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['customer_name']; ?></td>
                <td><?php echo $row['date']; ?></td>
                <td><?php echo $row['time']; ?></td>
                <td><?php echo $row['table_size']; ?></td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php
include 'includes/footer.php';
$conn->close();
?>
              