<?php include 'includes/db.php'; ?>
<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head> 
    <title>Reservations - The Gallery Café</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h2 class="text-center">Make a Reservation</h2>
        <form method="POST" action="process_reservation.php">
            <div class="form-group">
                <label for="customer_name">Your Name</label>
                <input type="text" class="form-control" id="customer_name" name="customer_name" required>
            </div>
            <div class="form-group">
                <label for="date">Date</label>
                <input type="date" class="form-control" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="time">Time</label>
                <input type="time" class="form-control" id="time" name="time" required>
            </div>
            <div class="form-group">
                <label for="table_size">Table Size</label>
                <input type="number" class="form-control" id="table_size" name="table_size" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit Reservation</button>
        </form>
    </div>
    <?php include 'includes/footer.php'; ?>
</body>
</html>
